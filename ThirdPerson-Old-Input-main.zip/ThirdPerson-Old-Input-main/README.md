# ThirdPerson-Old-Input
script, modelo e animações básicas
